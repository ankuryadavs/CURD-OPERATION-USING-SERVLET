package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.EmpModel;
import dao.EmpDao;
public class EmpDao {
	private String sql,sql1;
	private Connection conn;
	private PreparedStatement pst,pst1;
	private ResultSet rs;
	public EmpDao() throws ClassNotFoundException,SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		
	}
	public Integer addRecord(EmpModel e)throws SQLException
	{
		  sql1="select * from validation where name=?";
		  sql="insert into validation values(?,?,?,?)";
		  pst1=conn.prepareStatement(sql1);
		  pst=conn.prepareStatement(sql);
		  String s=e.getName();
		  String s1=e.getEmailid();
		  pst1.setString(1, e.getName());
		  ResultSet rs=pst1.executeQuery();
		  if(rs.next())
		  {
			  return 0;
		  }
		  else
		  {
		  boolean b2=s1.contains(" ");
				  if(b2==false)
				  {
					  pst.setString(1, e.getName());
					  pst.setLong(2,e.getMobileno());
					  pst.setString(3, e.getEmailid());
					  pst.setInt(4, e.getAge());
				  }
		  return pst.executeUpdate();
		  }
	}
	public Integer updateRecord(EmpModel e)throws SQLException
	{
		  sql="update validation set mobileno=?,emailid=?,age=? where name=?";
		  pst=conn.prepareStatement(sql);
		  
		  String s=e.getName();
		  String s1=e.getEmailid();
		  boolean b2=s1.contains(" ");
				  if(b2==false)
				  {
					  pst.setString(4, e.getName());
					  pst.setLong(1,e.getMobileno());
					  pst.setString(2, e.getEmailid());
					  pst.setInt(3, e.getAge());
				  }
		      
		  return pst.executeUpdate();
	}
	  public Integer deleteRecord(EmpModel t)throws SQLException
	  {
		  sql="delete from validation where name=?";
		  pst=conn.prepareStatement(sql);
		  pst.setString(1,t.getName());
		  return pst.executeUpdate();
	  }
	  public EmpModel findRecord(EmpModel t)throws SQLException,ClassNotFoundException
		{
			sql="select *from validation where name=?";
			pst=conn.prepareStatement(sql);
			 pst.setString(1,t.getName());
			  rs=pst.executeQuery();
			 rs.next();
			 t.setName(rs.getString("name"));
			 t.setMobileno(rs.getLong("mobileno"));
			 t.setEmailid(rs.getString("emailid"));
			 t.setAge(rs.getInt("age"));
			 return t;
	    }
	  public List<EmpModel> findAllRecord()throws SQLException,ClassNotFoundException
		{
			sql="select * from validation";
			pst=conn.prepareStatement(sql);
			List<EmpModel> l=new ArrayList<>();
			rs=pst.executeQuery();
			while(rs.next())
			{
				EmpModel e=new EmpModel();
			 e.setName(rs.getString("name"));
			 e.setMobileno(rs.getLong("mobileno"));
			 e.setEmailid(rs.getString("emailid"));
			 e.setAge(rs.getInt("age"));
			 l.add(e);
			}
			 return l;
	    }



}
