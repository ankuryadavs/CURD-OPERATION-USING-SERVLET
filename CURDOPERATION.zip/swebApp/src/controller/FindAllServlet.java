package controller;
import java.sql.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import model.*;
import dao.*;
public class FindAllServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	       res.setContentType("text/html");
	       PrintWriter out=res.getWriter();
	       try {
	       EmpModel e=new EmpModel();
	       EmpDao d=new EmpDao();
	      List<EmpModel> l=new ArrayList<>();
	      l=d.findAllRecord();
	      Iterator<EmpModel> itr=l.iterator();
	      int i=0;
	      out.println("<table border='1' height='100%' width='100%'>");
	      out.println("<tr>");
	      out.println("<td>"+"S.no"+"</td>");
	      out.println("<td>"+"Name"+"</td>");
	      out.println("<td>"+"Mobileno"+"</td>");
	      out.println("<td>"+"Emailid"+"</td>");
	      out.println("<td>"+"Age"+"</td>");
	      out.println("</tr>");
	      while(itr.hasNext()) {
	    	  e=itr.next();
	    	  out.println("<tr>");
	    	  i=i+1;
	    	  out.println("<td>"+i+"</td>");
	    	  out.println("<td>"+e.getName()+"</td>");
	    	  out.println("<td>"+e.getMobileno()+"</td>");
	    	  out.println("<td>"+e.getEmailid()+"</td>");
	    	  out.println("<td>"+e.getAge()+"</td>");
	    	  out.println("</tr>");
	    	 
	      }
	      out.println("</table>");
	       }
	      catch(Exception e)
	      {
	    	  out.println(e);
	      }
}
}


