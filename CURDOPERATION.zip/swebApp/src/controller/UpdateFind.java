package controller;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import model.*;
import dao.*;
public class UpdateFind extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	       res.setContentType("text/html");
	       PrintWriter out=res.getWriter();
	       String name=req.getParameter("name");
	     try
	     {
	    	 EmpModel t=new EmpModel();
	    	 t.setName(name);
	    	 EmpDao d=new EmpDao();
	    	 EmpModel x=d.findRecord(t);
	    	 out.println("<center>");
	    	 out.println("<table>");
	    	 out.println("<form method='post' action='update'>");
	    	 out.println("<tr>"+"<td>"+"Name:"+"</td>"+"<td>"+"<input type='text' name='name' value="+t.getName()+">"+"</td>"+"</tr>");
	    	 out.println("<tr>"+"<td>"+"Mobile no:"+"</td>"+"<td>"+"<input type='text' name='mobileno' value="+t.getMobileno()+">"+"</td>"+"</tr>");
	    	 out.println("<tr>"+"<td>"+"Emailid:"+"<td>"+"<input type='text' name='emailid' value="+t.getEmailid()+">"+"</td>"+"</tr>");
	    	 out.println("<tr>"+"<td>"+"Age:"+"</td>"+"<td>"+"<input type='text' name='age' value="+t.getAge()+">"+"</td>"+"</tr>");
	    	 out.println("<tr>"+"<td colspan='2'>"+"<input type='submit' value='Modify'>"+"</td>"+"</tr>");
	    	 out.println("</form>"+"</table>");
	    	 out.println("</center>");
	       }
	       catch(Exception e)
		      {
		      out.println(e);
		      }
	}
}
