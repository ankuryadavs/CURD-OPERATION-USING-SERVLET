package controller;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import model.*;
import dao.*;
public class FindServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	       res.setContentType("text/html");
	       PrintWriter out=res.getWriter();
	       String name=req.getParameter("name");
	     try
	     {
	    	 EmpModel t=new EmpModel();
	    	 t.setName(name);
	    	 EmpDao d=new EmpDao();
	    	 EmpModel x=d.findRecord(t);
	    	 out.println("<table border='1'>");
	    	 out.println("<tr>");
	    	 out.println("<td>"+"Name"+"</td>");
	    	 out.println("<td>"+"Emailid"+"</td>");
	    	 out.println("<td>"+"Mobileno"+"</td>");
	    	 out.println("<td>"+"Age"+"</td>");
	    	 out.println("</tr>");
	    	 out.println("<tr>");
	    	 out.println("<td>"+t.getName()+"</td>");
	    	 out.println("<td>"+t.getEmailid()+"</td>");
	    	 out.println("<td>"+t.getMobileno()+"</td>");
	    	 out.println("<td>"+t.getAge()+"</td>");
	    	 out.println("</tr>"+"</table>");
	    	 
	      }
	       catch(Exception e)
		      {
		      out.println(e);
		      }
	}
}
