package controller;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import model.EmpModel;
import dao.EmpDao;
public class AddServlet extends HttpServlet
{
	
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		
	       res.setContentType("text/html");
	       PrintWriter out=res.getWriter();
	       String name=req.getParameter("name");
	       String mobileno1=req.getParameter("mobileno");
	       String emailid=req.getParameter("emailid");
	       String age=req.getParameter("age");
	       int a=0,y=0;
	       if(emailid.contains("@"))
	       {
	    	  a++;
	    	 
	    		  Long mobileno=Long.parseLong(mobileno1);
		    	if((mobileno1.length()==10))
		    	{
		    		y++;
		    	
	        try
	       {
	    	EmpDao d=new EmpDao();
	    	EmpModel t=new EmpModel(); 
	    	 t.setName(name);
	    	 t.setMobileno(mobileno);
	    	 t.setEmailid(emailid);
	    	 Integer age1=Integer.parseInt(age);
	    	 t.setAge(age1);
	       Integer x=d.addRecord(t);
	       if(x==0)
	       {
	    	   out.println("<center>"+"name alreday exist use another name"+"</center><br><br>");
		       RequestDispatcher rd=req.getRequestDispatcher("addservlet.html");
		       rd.include(req, res);
	       }
	       else
	       {
	       out.println("<center>"+x+"record added successfully"+"</center>");
	       RequestDispatcher rd=req.getRequestDispatcher("addservlet.html");
	       rd.include(req, res);
	       }
	      }
	       catch(NumberFormatException e)
		      {
		      out.println("<center>"+"check your age"+"</center>");
		      RequestDispatcher rd=req.getRequestDispatcher("addservlet.html");
   	       rd.include(req, res);
		      }
	        catch(Exception e)
		      {
		      out.println(e);
		      }
	       }
	     }
	      if(a==0)
	      {
	    	  out.println("check your emailid");
	    	RequestDispatcher rd=req.getRequestDispatcher("addservlet.html");
	    	       rd.include(req, res);
	      }
	      else if(a==1 && y==0)
	      {
	    	  out.println("<center>"+"check your mobileno"+"</center>");
		    	RequestDispatcher rd=req.getRequestDispatcher("addservlet.html");
		    	       rd.include(req, res);
	      }
	 }
}
